"""Taskocalypse test suite."""
